package net.aetherteam.aether.launcher.process;

public abstract interface JavaProcessRunnable {

	public abstract void onJavaProcessEnded(JavaProcess paramJavaProcess);
}