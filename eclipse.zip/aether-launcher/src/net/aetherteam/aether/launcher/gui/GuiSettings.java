package net.aetherteam.aether.launcher.gui;

import org.newdawn.slick.Color;

public class GuiSettings {

	public Color backgroundColor;

	public Color textFieldColor;

	public Color textFieldHoveredColor;

	public int fadeSpeed;
}
